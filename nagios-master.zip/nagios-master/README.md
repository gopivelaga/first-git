# nagios
This repo consists of setup files required for Nagios Server and Nagios machinces
