name "opsworks_shutdown"
description "Cleans up before an instance as actually shut down on EC2"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends "opsworks_agent_monit"
