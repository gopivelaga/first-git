name        "opsworks_java"
description 'Installs and configures a Java application server'
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends 'apache2'
