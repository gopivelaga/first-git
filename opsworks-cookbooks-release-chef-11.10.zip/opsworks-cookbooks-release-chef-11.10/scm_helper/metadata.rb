name        "scm_helper"
description "Offers a few library functions to interact with source control systems"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends "opsworks_commons"
depends "s3_file"
