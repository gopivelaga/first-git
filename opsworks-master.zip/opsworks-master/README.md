# opsworks
This repo consists of all required recipes for OpsWorks
