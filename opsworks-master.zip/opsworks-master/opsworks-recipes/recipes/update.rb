# Run an update on the box.
execute "apt-get-update" do
  command "apt-get update"
end
