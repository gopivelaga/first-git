# elasticsearch-logstash-kibana
This repo servers for setup files required for elasticsearch-logstash-kibana
